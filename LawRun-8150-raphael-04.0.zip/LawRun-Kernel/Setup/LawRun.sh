#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
############################## Installation ####################################

# Clear
ui_print "";
ui_print "";

# If magisk installed will go with installation way
if [ "$magisk_present" = true ]; then
mkdir -p /data/adb/modules
cp -R /tmp/anykernel/LawRun-Kernel/Setup/Lawrunkernel /data/adb/modules
ui_print "                                                  "
ui_print "                                                  "
ui_print " This is LawRun-Kernel Installation you can follow it to choose what you want to install"
ui_print "                                                  "
ui_print "                                                  "
else
# If magisk not installed will go with Default build
ui_print "Magisk Not detected"
ui_print "Default Build will be installed"
ui_print "-> Default build will be listed in your build post check our website";
. /tmp/anykernel/LawRun-Kernel/Setup/ForceUnRooted.sh

fi # end magisk
########################### Test Keys-Vol+ Vol- ################################

# Clear
ui_print "";
ui_print "";

keytest() {
  ui_print "   Press a Vol Key..."
  (/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > /tmp/anykernel/events) || return 1
  return 0
}

chooseport() {
  #note from chainfire @xda-developers: getevent behaves weird when piped, and busybox grep likes that even less than toolbox/toybox grep
  while (true); do
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > /tmp/anykernel/events
    if (`cat /tmp/anykernel/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
      break
    fi
  done
  if (`cat /tmp/anykernel/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
    return 0
  else
    return 1
  fi
}

chooseportold() {
  # Calling it first time detects previous input. Calling it second time will do what we want
  $bin/keycheck
  $bin/keycheck
  SEL=$?
  if [ "$1" == "UP" ]; then
    UP=$SEL
  elif [ "$1" == "DOWN" ]; then
    DOWN=$SEL
  elif [ $SEL -eq $UP ]; then
    return 0
  elif [ $SEL -eq $DOWN ]; then
    return 1
  else
    abort "   Vol key not detected!"
  fi
}

if [ "$magisk_present" = true ]; then
if [ ! -f /data/lawrunconfig/skip ]; then
if keytest; then
  FUNCTION=chooseport
else
  FUNCTION=chooseportold
  ui_print "   Press Vol Up Again..."
  $FUNCTION "UP"
  ui_print "   Press Vol Down..."
  $FUNCTION "DOWN"
fi

############################# Install-Kernel ###################################

# Clear
ui_print "";
ui_print "";

if [ -d /tmp/anykernel/LawRun-Kernel/Files/Test ]; then

. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh FastGo

else

 ### Kernel Img ###

if [ -d /tmp/anykernel/LawRun-Kernel/Check/realme ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/miatoll ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/davinci ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/cepheus ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/surya ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/sweet ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/alioth ];then

ui_print "Default Build"
	mv /tmp/anykernel/LawRun-Kernel/kernel/Old/Image.gz-dtb $home;

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ];then
# Choose SystemExt
ui_print " "
ui_print " "
ui_print "- Choose Your Rom Support Qti or no? -"
ui_print "- If your rom support Qti? -"
ui_print "- If you dont know ask the rom maintainer! -"
ui_print "   Yes!!... support"
ui_print "   no!!... Not support"
if $FUNCTION; then
ui_print "-> You said your rom support...";
LorO=Latest
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
else
ui_print "-> You said your rom not support...";
LorO=Old
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
fi

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/vayu ];then

ui_print "Default Build"
	mv /tmp/anykernel/LawRun-Kernel/kernel/Old/Image $home;
	mv /tmp/anykernel/LawRun-Kernel/kernel/Old/dtbo.img $home;
	mv /tmp/anykernel/LawRun-Kernel/kernel/Old/dtb.img $home;

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/raphael ];then

ui_print "Default Build"
LorO=Old
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/xxx ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/xxx ]; then
# Choose img
ui_print " "
ui_print "- Choose Your Rom supports Old or New CAM? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... New CAM"
ui_print "   no!!... Old CAM"
if $FUNCTION; then
ui_print "-> Latest CAM...";
## Install Img
ui_print "-> Installing Img...";
LorO=Latest
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
else
ui_print "-> Old CAM...";
# Install Img
ui_print "-> Installing Img...";
LorO=Old
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
fi # End function

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/beryllium ]; then
# Choose firmware
ui_print " "
ui_print "- Choose Your favorite Touch Firmwares? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... old touch firmwares"
ui_print "   no!!... latest touch firmwares"
if $FUNCTION; then
ui_print "-> Old touch firmwres...";
# Install Img
LorO=Old
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
else
ui_print "-> Latest touch firmwres...";
## Install Img
LorO=Latest
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
fi # End function

fi # End Devices check

 ### Kernel Dtb ###

if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ];then
# Choose SystemExt
ui_print " "
ui_print " "
ui_print "- Choose Your Rom Support Qti or no? -"
ui_print "- If your rom support Qti? -"
ui_print "- If you dont know ask the rom maintainer! -"
ui_print "   Yes!!... support"
ui_print "   no!!... Not support"
if $FUNCTION; then
ui_print "-> You said your rom support...";
LorO=Latest
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
# Choose dts
ui_print " "
ui_print "- Choose If you want Oc or Sk? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Overclocked build"
ui_print "   no!!... Stock Build"
if $FUNCTION; then
ui_print " "
ui_print "- Choose If you want Hyper Oc or Normal Oc? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Hyper Overclocked build = 2.45 CPU"
ui_print "   no!!... Normal Overclocked Build = 2.20 CPU"
if $FUNCTION; then
# LawRun Hyper Module
ui_print "-> Installing Hyper Overclocked Img...";
ModulePath=/sdm660
ModuleName=/HyperOc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Sk ]; then
Whichrm=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/Oc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=0;
b=1;
c=1;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
else
# LawRun Oc Module
ui_print "-> Installing Normal Overclocked Img...";
ModulePath=/sdm660
ModuleName=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Sk ]; then
Whichrm=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/HyperOc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=1;
b=0;
c=0;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
fi # ENd Function
else
# LawRun Sk Module
ui_print "-> Installing Stock Img...";
ModulePath=/sdm660
ModuleName=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Oc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/HyperOc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=0;
b=0;
c=0;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
fi # ENd Function
else
ui_print "-> You said your rom not support...";
LorO=Old
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
# Choose dts
ui_print " "
ui_print "- Choose If you want Oc or Sk? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Overclocked build"
ui_print "   no!!... Stock Build"
if $FUNCTION; then
ui_print " "
ui_print "- Choose If you want Hyper Oc or Normal Oc? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Hyper Overclocked build = 2.45 CPU"
ui_print "   no!!... Normal Overclocked Build = 2.20 CPU"
if $FUNCTION; then
# LawRun Hyper Module
ui_print "-> Installing Hyper Overclocked Img...";
ModulePath=/sdm660
ModuleName=/HyperOc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Sk ]; then
Whichrm=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/Oc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=1;
b=1;
c=1;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
else
# LawRun Oc Module
ui_print "-> Installing Normal Overclocked Img...";
ModulePath=/sdm660
ModuleName=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Sk ]; then
Whichrm=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/HyperOc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=1;
b=0;
c=0;
d=0;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
fi # ENd Function
else
# LawRun Sk Module
ui_print "-> Installing Stock Img...";
ModulePath=/sdm660
ModuleName=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Oc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/HyperOc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=0;
b=0;
c=0;
d=0;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
fi # ENd Check
fi # ENd Function

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ]; then
# Choose SystemExt
ui_print " "
ui_print " "
ui_print "- Choose Your Rom Support Qti or no? -"
ui_print "- If your rom support Qti? -"
ui_print "- If you dont know ask the rom maintainer! -"
ui_print "   Yes!!... support"
ui_print "   no!!... Not support"
if $FUNCTION; then
ui_print "-> You said your rom support...";
LorO=Latest
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
# Choose img
ui_print " "
ui_print "- Choose If you want Oc or Sk? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Overclocked build"
ui_print "   no!!... Stock Build"
if $FUNCTION; then
# LawRun Oc Module
ui_print "-> Installing Overclocked Img...";
ModulePath=/sdm660
ModuleName=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Sk ]; then
Whichrm=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=0;
b=1;
c=1;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
else
# LawRun Sk Module
ui_print "-> Installing Stock Img...";
ModulePath=/sdm660
ModuleName=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Oc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=0;
b=0;
c=0;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
fi # ENd Check
else
ui_print "-> You said your rom not support...";
LorO=Old
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh KernelImg
# Choose img
ui_print " "
ui_print "- Choose If you want Oc or Sk? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Overclocked build"
ui_print "   no!!... Stock Build"
if $FUNCTION; then
# LawRun Oc Module
ui_print "-> Installing Overclocked Img...";
ModulePath=/sdm660
ModuleName=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Sk ]; then
Whichrm=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=1;
b=1;
c=1;
d=1;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
else
# LawRun Sk Module
ui_print "-> Installing Stock Img...";
ModulePath=/sdm660
ModuleName=/Sk
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
# LawRun Remove Module
if [ -d /data/adb/modules/Oc ]; then
Whichrm=/Oc
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
# DtsInstalling
a=0;
b=0;
c=0;
d=0;
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg
fi # ENd Check
fi # ENd Function

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/raphael ]; then
# Choose GPU
ui_print " "
ui_print " "
ui_print "- Do you want GPU Oc? -"
ui_print "- Warning Use At your own risk? -"
ui_print "- Try to handle your phone temp? -"
ui_print "   Yes!!..."
ui_print "   no!!..."
if $FUNCTION; then
ui_print "-> Installing GPU Oc build...";
	a=1;
	b=1;
	c=1;
	d=1;
else
ui_print "-> Installing GPU Sk build...";
	a=0;
	b=0;
	c=0;
	d=0;
fi

# Install dts
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg

# 60hz
    patch_cmdline "msm_drm.framerate_override" "msm_drm.framerate_override="""

elif [ -d /tmp/anykernel/LawRun-Kernel/Check/beryllium ]; then
# Choose SystemExt
ui_print " "
ui_print " "
ui_print "- Choose Your Rom SystemExt Partition? -"
ui_print "- If your rom support SystemExt? -"
ui_print "- If you dont know ask the rom maintainer! -"
ui_print "   Yes!!... support"
ui_print "   no!!... Not support"
if $FUNCTION; then
ui_print "-> You said your rom support...";
	a=1;
else
ui_print "-> You said your rom not support...";
	a=0;
fi

# Choose Thermals
ui_print " "
ui_print " "
ui_print "- Choose Your Rom Thermals? -"
ui_print "- If your rom support ThermalHAL-Util, pixel thermals? -"
ui_print "- If you dont know ask the rom maintainer! -"
ui_print "   Yes!!... support"
ui_print "   no!!... Not support"
if $FUNCTION; then
ui_print "-> You said your rom support...";
	b=1;
else
ui_print "-> You said your rom not support...";
	b=0;
fi

# Choose GPU
ui_print " "
ui_print " "
ui_print "- Do you want GPU Oc? -"
ui_print "- Warning Use At your own risk? -"
ui_print "- Try to handle your phone temp? -"
ui_print "   Yes!!..."
ui_print "   no!!..."
if $FUNCTION; then
ui_print "-> Installing GPU Oc build...";
	c=1;
else
ui_print "-> Installing GPU Sk build...";
	c=0;
fi

# Choose Charging
ui_print " "
ui_print " "
ui_print "- Do you want Charging Oc? -"
ui_print "- Warning Use At your own risk? -"
ui_print "- Try to handle your phone temp? -"
ui_print "   Yes!!..."
ui_print "   no!!..."
if $FUNCTION; then
ui_print "-> Installing Charging Oc build...";
	d=1;
else
ui_print "-> Installing Charging Sk build...";
	d=0;
fi

# Install dts
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh dtsImg

fi # End Dtb devices

# Choose Displayhz
if [ -d /tmp/anykernel/LawRun-Kernel/Check/realme ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/beryllium ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ]; then
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DisplayOC
fi

############################# Magisk-Modules ###################################

# Clear
ui_print "";
ui_print "";

if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ] ; then
# LawRun Core Module
if [ -d /data/adb/modules/LawRun ]; then
Whichrm=/LawRun
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi

else
# LawRun Core Module
ui_print "-> Installing LawRun Magisk Module...";
MODMagisk=/data/adb/modules/LawRun
# Place MOD options
rm -rf $MODMagisk
mkdir -p $MODMagisk
if [ -d /tmp/anykernel/LawRun-Kernel/Check/realme ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/realme/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/raphael ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/raphael/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/miatoll ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/miatoll/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/davinci ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/davinci/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/vayu ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/vayu/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/cepheus ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/cepheus/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/surya ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/surya/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/sweet ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/sweet/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/alioth ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/alioth/LawRun/* $MODMagisk
elif [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices/wayne/LawRun/* $MODMagisk
else
cp -Rf /tmp/anykernel/LawRun-Kernel/common/LawRun/* $MODMagisk
fi
chmod 755 $MODMagisk/service.sh

fi # End whyred & lavender check

# kcal
ui_print " "
ui_print "- Do you want LawRun Display Amoled colors? -"
ui_print "   Vol+ = Yes, Vol- = No"
if $FUNCTION; then
# LawRun Display colors
ui_print "-> Installing KCAL Magisk Module...";
LRKModule=/Kcal
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRKModules
else
if [ -d /data/adb/modules/Kcal ]; then
Whichrm=/Kcal
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
fi

if [ ! -d /tmp/anykernel/LawRun-Kernel/Check/vayu ] || [ ! -d /tmp/anykernel/LawRun-Kernel/Check/alioth ]; then
if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ]; then
# SDM660_EAS_perfHAL_Module
ui_print " "
ui_print "- Do you want EAS_perfHAL Thermal? -"
ui_print "   Vol+ = Yes, Vol- = No"
if $FUNCTION; then
ui_print "-> Installing EAS_perfHAL Magisk Module...";
ModulePath=/sdm660
ModuleName=/SDM660_EAS_perfHAL_Module
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh DeviceModules
else
ui_print "Skipping..."
if [ -d /data/adb/modules/SDM660_EAS_perfHAL_Module ]; then
Whichrm=/SDM660_EAS_perfHAL_Module
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
fi

else
# Thermals selection
ui_print " "
ui_print "-  Do you want LawRun Thermals? -"
ui_print "-  For Best Charging speed & Performance!! - "
ui_print "   Vol+ = Yes, Vol- = No"
if $FUNCTION; then
ui_print "-  Built-in Or Magisk ? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print " Yes,Built-in one which is better"
ui_print " No,the Magisk Module"
# Built-in Thermal
if $FUNCTION; then
ui_print "-> Installing LawRun Built-in Thermals";
ui_print "-> Dont Cry of heating...";
ui_print "-> Reflash your rom is recommended to remove it";
# Custom Thermal
. /tmp/anykernel/LawRun-Kernel/Setup/Thermal.sh;
cp -R /tmp/anykernel/LawRun-Kernel/common/Thermals /data/adb/modules
else
ui_print "-> Installing LawRun Thermals as a magisk module";
ui_print "-> Dont Cry of Heating...";
MODMagisk=/data/adb/modules/LawRun-Thermals
# Place MOD options
rm -rf $MODMagisk
mkdir -p $MODMagisk
if [ -d /tmp/anykernel/LawRun-Kernel/Check/realme ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/raphael ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/miatoll ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/davinci ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/cepheus ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/surya ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/sweet ]; then
cp -Rf /tmp/anykernel/LawRun-Kernel/common/LawRun-Thermals_x/* $MODMagisk
else
cp -Rf /tmp/anykernel/LawRun-Kernel/common/LawRun-Thermals/* $MODMagisk
fi
chmod 755 $MODMagisk/service.sh
fi
else
ui_print "Skipping..."
if [ -d /data/adb/modules/LawRun-Thermals ]; then
# Clear LawRun Thermals Magisk module
Whichrm=/LawRun-Thermals
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
if [ -d /data/adb/modules/LawRun-Thermals_x ]; then
# Clear LawRun Thermals Magisk module
Whichrm=/LawRun-Thermals_x
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun_Functions.sh LRRemoveModule
fi
fi
fi # End whyred check
fi

fi # End test check

# LICENSE
. /tmp/anykernel/LawRun-Kernel/Setup/LICENSE.sh;

############################### LawRun-End #####################################

fi
fi
