#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
#############################LawRun-Initation###################################

# Clear
ui_print "                                    ";
ui_print "                                    ";

############################# LawRun-LICENSE ###################################

# Install LawRun Finall installation

# Start magisk checker
magisk_check;

## AnyKernel boot install
if [ "$magisk_present" = true ]; then
dump_boot;
else
split_boot;
fi

# LawRun Setup
. /tmp/anykernel/LawRun-Kernel/Setup/LawRun.sh;

# Final booting
if [ "$magisk_present" = true ]; then
  write_boot;
else
  flash_boot;
  flash_dtbo;
fi

############################### LawRun-End #####################################
