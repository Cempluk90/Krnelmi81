#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
#############################LawRun-Initation###################################

# Clear
ui_print "                                    ";
ui_print "                                    ";

############################# LawRun-LICENSE ###################################

# Install LawRun summary
	ui_print "                 LawRun summary                ";
ui_print "                                    ";
ui_print "                                    ";
if [ "$magisk_present" = true ]; then
if [ -d /data/adb/modules/LawRun ] || [ -d /data/adb/modules/Oc ] || [ -d /data/adb/modules/Sk ]; then
    ui_print "LawRun Kernel Module Installed...";
fi;
if [ -d /data/adb/modules/LawRunProfiles ]; then
    ui_print "LawRun Profiles Module Installed...";
fi;
if [ -d /data/adb/modules/Kcal ]; then
    ui_print "LawRun Display Colors Installed...";
fi;
if [ -d /data/adb/modules/Thermals ]; then
    ui_print "LawRun Thermal Installed (Built-in)...";
rm -rfv /data/adb/modules/Thermals;
if [ -d /data/adb/modules/LawRun-Thermals ]; then
# Clear LawRun Thermals Magisk module
MODMagisk=/data/adb/modules/LawRun-Thermals
# Place MOD options
rm -rf $MODMagisk
rm -rfv /data/adb/modules/LawRun-Thermals;
fi
fi
if [ -d /data/adb/modules/LawRun-Thermals ] || [ -d /data/adb/modules/LawRun-Thermals_x ] ; then
    ui_print "LawRun Thermal Installed (Magisk)...";
fi
if [ -d /data/adb/modules/Uclamp ]; then
    ui_print "Uclamp Module Installed...";
if [ -d /tmp/anykernel/LawRun-Kernel/Check/beryllium ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ]; then
Whichrm=/Uclamp
MODMagisk=/data/adb/modules$Whichrm
# Place MOD options
rm -rf $MODMagisk
rm -rfv /data/adb/modules$Whichrm
    ui_print "Uclamp Module Pre-Installed...";
fi
fi;
if [ -d /data/adb/modules/gPhotos ]; then
    ui_print "LawRun gPhotos Module Installed...";
fi;
if [ -d /data/adb/modules/LawRunUNlockTool ]; then
    ui_print "Graphic Unlocker Module Installed...";
fi;
if [ -d /data/adb/modules/Permissiver ]; then
    ui_print "LawRun Permissiver Included...";
rm -rfv /data/adb/modules/Permissiver;
fi;

else
ui_print "                                    ";
fi
    ui_print "                                    ";
    ui_print "Download Our App from our website linked below...";
    ui_print "Website ==> https://lawrun-kernel.blogspot.com...";
    ui_print "Telegram ==> https://t.me/LawRunKernel...";
    ui_print "Email ==> lawrunbynegrroo@gmail.com...";
    ui_print "                  Dont forget                    ";
    ui_print "            ALWAYS BE READY TO RUN!!              ";

############################### LawRun-End #####################################
