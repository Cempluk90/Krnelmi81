#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
#############################LawRun-Initation###################################

# Clear
ui_print "                                    ";
ui_print "                                    ";

############################# LawRun-LICENSE ###################################

# Install LawRun without root

if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/beryllium ]; then
# KernelInstalling
LorO=Old
KernelImg

# DtsInstalling
a=0;
b=0;
c=0;
dtsImg

else
	mv /tmp/anykernel/LawRun-Kernel/kernel/Old/Image.gz-dtb $home;

fi # end devices

if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ]; then
framerateFile=mdss_dsi
else
framerateFile=msm_drm
fi

# 60hz
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override="""

############################### LawRun-End #####################################
