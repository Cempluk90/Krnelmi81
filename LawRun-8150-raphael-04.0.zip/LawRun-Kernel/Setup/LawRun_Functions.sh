#!/sbin/sh

################################################################################
            #=================================================#
            #        **          ******      negrroo          #
            #        **          *    *      **   **          #
            #        **          ******      **  **           #
            #        **          **          *****            #
            #        *******     ** **       **  **           #
            #        *******     **   **     **   **          #
            #=================================================#
############################## Installation ####################################

# Set first parameter to function
function=$1

KernelImg() {
# Install Img
ui_print "-> Installing Img...";
	decompressed_image=$home/LawRun-Kernel/kernel/$LorO/Image;
	compressed_image=$decompressed_image.gz;
}

dtsImg() {
# Install dts

if [ "$a" == "" ]; then
a=0;
fi
if [ "$b" == "" ]; then
b=0;
fi
if [ "$c" == "" ]; then
c=0;
fi
if [ "$d" == "" ]; then
d=0;
fi
	if [ -f $compressed_image ]; then
	  # Concatenate all of the dtbs to the kernel
	  cat $compressed_image $home/LawRun-Kernel/kernel/Specific/"$a$b$c$d"/*.dtb > $home/Image.gz-dtb;
	fi;
}

DisplayOC() {

if [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ]; then
framerateFile=mdss_dsi

if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ]; then
# Choose dts
ui_print " "
ui_print "- Choose your favorite display hz? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 60hz"
ui_print "   No!!... you will have 62hz"
ui_print "                     "
if $FUNCTION; then
ui_print "-> Installing Img + 60hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override="""
else
# 62hz
ui_print "-> Installing Img + 62hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=1"
fi # End function
fi # Whyred

else
framerateFile=msm_drm
fi

if [ ! -d /tmp/anykernel/LawRun-Kernel/Check/whyred ]; then
# Choose dts
ui_print " "
ui_print "- Choose your favorite display hz? -"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 60hz"
ui_print "   No!!... Choose again (62, 63, 65, 66, 67, 68, 69, 70, 71)"
ui_print "                     "
if $FUNCTION; then
ui_print "-> Installing Img + 60hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override="""
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 62hz"
ui_print "   No!!... Choose again (63, 65, 66, 67, 68, 69, 70, 71)"
ui_print "                     "
# 62hz
if $FUNCTION; then
ui_print "-> Installing Img + 62hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=1"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 63hz"
ui_print "   No!!... Choose again (65, 66, 67, 68, 69, 70, 71)"
ui_print "                     "
if $FUNCTION; then
# 63hz
ui_print "-> Installing Img + 63hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=2"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 65hz"
ui_print "   No!!... Choose again (66, 67, 68, 69, 70, 71)"
ui_print "                     "
if $FUNCTION; then
# 65hz
ui_print "-> Installing Img + 65hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=3"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 66hz"
ui_print "   No!!... Choose again (67, 68, 69, 70, 71)"
ui_print "                     "
if $FUNCTION; then
# 66hz
ui_print "-> Installing Img + 66hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=4"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 67hz"
ui_print "   No!!... Choose again (68, 69, 70, 71)"
ui_print "                     "
if $FUNCTION; then
# 67hz
ui_print "-> Installing Img + 67hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=5"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 68hz"
ui_print "   No!!... Choose again (69, 70, 71)"
ui_print "                     "
if $FUNCTION; then
# 68hz
ui_print "-> Installing Img + 68hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=6"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 69hz"
ui_print "   No!!... Choose again (70, 71)"
ui_print "                     "
if $FUNCTION; then
# 69hz
ui_print "-> Installing Img + 69hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=7"
else
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... you will have 70hz"
ui_print "   No!!... you will have 71hz"
ui_print "                     "
if $FUNCTION; then
# 70hz
ui_print "-> Installing Img + 70hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=8"
else
# 71hz
ui_print "-> Installing Img + 71hz...";
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override=9"
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
}

LRKModules() {
MODMagisk=/data/adb/modules$LRKModule
# Place MOD options
rm -rf $MODMagisk
mkdir -p $MODMagisk
cp -Rf /tmp/anykernel/LawRun-Kernel/common$LRKModule/* $MODMagisk
chmod 755 $MODMagisk/service.sh
}

LRRemoveModule() {
# Clear LawRun Thermals Magisk module
ui_print "Skipping..."
MODMagisk=/data/adb/modules$Whichrm
# Place MOD options
rm -rf $MODMagisk
rm -rfv /data/adb/modules$Whichrm
}

DeviceModules() {
MODMagisk=/data/adb/modules$ModuleName
# Place MOD options
rm -rf $MODMagisk
mkdir -p $MODMagisk
cp -Rf /tmp/anykernel/LawRun-Kernel/Devices$ModulePath$ModuleName/* $MODMagisk
chmod 755 $MODMagisk/service.sh
}

WithoutMagisk() {

if [ -d /tmp/anykernel/LawRun-Kernel/Check/realme ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/raphael ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/davinci ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/miatoll ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/vayu ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/alioth ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/cepheus ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/surya ]; then

	mv /tmp/anykernel/LawRun-Kernel/kernel/Old/Image.gz-dtb $home;

if [ -d /tmp/anykernel/LawRun-Kernel/Check/realme ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/raphael ]; then
# 60hz
    patch_cmdline "msm_drm.framerate_override" "msm_drm.framerate_override="""
fi # End realme check

else

# KernelInstalling
LorO=Old
KernelImg

# DtsInstalling
a=0;
b=0;
c=0;
d=0;
dtsImg

if [ -d /tmp/anykernel/LawRun-Kernel/Check/whyred ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/lavender ] || [ -d /tmp/anykernel/LawRun-Kernel/Check/wayne ]; then
framerateFile=mdss_dsi
else
framerateFile=msm_drm
fi
# 60hz
    patch_cmdline "$framerateFile.framerate_override" "$framerateFile.framerate_override="""

fi # end devices
}

FastGo() {
# KernelInstalling
	LorO=Old
KernelImg

# DtsInstalling
	a=1;
	b=1;
	c=1;
	d=1;
dtsImg

# Default displayhz
ui_print "-> Installing Img + 60hz...";
    patch_cmdline "msm_drm.framerate_override" "msm_drm.framerate_override="""

# LawRun Core Module
ui_print "-> Installing LawRun Magisk Module...";
LRKModule=/LawRun
LRKModules

# LawRun Display colors
#ui_print "-> Installing Profiles Magisk Module...";
#LRKModule=/LawRunProfiles
#LRKModules

# LawRun Display colors
ui_print "-> Installing KCAL Magisk Module...";
LRKModule=/Kcal
LRKModules

# LawRun Magisk Thermals
#ui_print "-> Installing LawRun Thermals as a magisk module";
#ui_print "-> Dont Cry of Heating...";
#LRKModule=/LawRun-Thermals
#LRKModules

# Uclamp Module
#ui_print "-> Installing Uclamp Module...";
#LRKModule=/Uclamp
#LRKModules

# gPhotos Module
#ui_print "-> Installing gPhotos Module...";
#LRKModule=/gPhotos
#LRKModules
}


# Function Selection
if [ $function == 'FastGo' ]
then
FastGo

elif [ $function == 'WithoutMagisk' ]
then
WithoutMagisk

elif [ $function == 'DeviceModules' ]
then
DeviceModules

elif [ $function == 'LRRemoveModule' ]
then
LRRemoveModule

elif [ $function == 'LRKModules' ]
then
LRKModules

elif [ $function == 'KernelImg' ]
then
KernelImg

elif [ $function == 'dtsImg' ]
then
dtsImg

elif [ $function == 'DisplayOC' ]
then
DisplayOC

fi

############################### LawRun-End #####################################
