#!/system/bin/sh

#Installed with LawRun Kernel
#Script by @negrroo

# Detect Kernel version
   setprop lawrun.kernel.name "LawRun_v00.7"
