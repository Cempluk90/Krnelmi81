# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=       !!!!!LawRun-Kernel by negrroo!!!!!
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=beryllium
device.name2=dipper
device.name3=polaris
device.name4=lavender
device.name5=RMX1971
device.name6=RMX1851
device.name7=whyred
device.name8=raphael
device.name9=raphaelin
device.name10=curtana
device.name11=excalibur
device.name12=joyeuse
device.name13=gram
device.name14=davinci
device.name15=davinciin
device.name16=miatoll
device.name17=alioth
device.name18=aliothin
device.name19=cepheus
device.name20=vayu
device.name21=wayne
device.name22=surya
device.name23=karna
device.name24=surya_in
device.name25=karna_in
device.name26=sweet
device.name27=sweetin
device.name28=RMX1901
device.name29=
device.name30=
supported.versions=
supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=auto;
ramdisk_compression=auto;

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
#set_perm_recursive 0 0 750 750 $ramdisk/*;

# New Magisk Checker
. /tmp/anykernel/LawRun-Kernel/Setup/ForceCheckRoot.sh

# LawRun Setup & Finalizing
. /tmp/anykernel/LawRun-Kernel/Setup/FinalInstallation.sh

## end boot install
